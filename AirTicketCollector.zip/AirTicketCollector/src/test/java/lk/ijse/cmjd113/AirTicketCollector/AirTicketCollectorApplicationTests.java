package lk.ijse.cmjd113.AirTicketCollector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirTicketCollectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
