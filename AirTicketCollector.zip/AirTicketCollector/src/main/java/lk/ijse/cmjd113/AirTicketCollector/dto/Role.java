package lk.ijse.cmjd113.AirTicketCollector.dto;

public class Role {
    ADMIN ,
    USER ,
}
