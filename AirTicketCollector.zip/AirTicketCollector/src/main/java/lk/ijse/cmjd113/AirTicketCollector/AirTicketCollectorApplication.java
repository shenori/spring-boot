package lk.ijse.cmjd113.AirTicketCollector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirTicketCollectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirTicketCollectorApplication.class, args);
	}

}
