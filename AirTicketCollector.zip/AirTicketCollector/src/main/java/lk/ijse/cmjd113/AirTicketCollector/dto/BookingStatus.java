package lk.ijse.cmjd113.AirTicketCollector.dto;

public class BookingStatus {
    CONFIRMED 
    PENDING,
    CANCELLED
}
