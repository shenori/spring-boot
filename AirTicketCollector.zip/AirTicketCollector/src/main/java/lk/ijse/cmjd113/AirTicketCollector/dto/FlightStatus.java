package lk.ijse.cmjd113.AirTicketCollector.dto;

public class FlightStatus {
    AVAILABLE ,
    CANCELLED , 
    NOT_SCHEDULED ,
    OUT_OF_SERVICE
}
